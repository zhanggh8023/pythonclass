create view v_table_column_has_operation as
  select `t2`.`Source_Table_ID`                             AS `Source_Table_id`,
         `t2`.`Source_Table_Name`                           AS `Source_Table_Name`,
         `t2`.`Source_Table_Zh_Name`                        AS `Source_Table_Zh_Name`,
         `t1`.`Column_ID`                                   AS `Column_ID`,
         `t1`.`Column_Name`                                 AS `Column_Name`,
         `t1`.`Column_Type`                                 AS `Column_Type`,
         `t1`.`Alias_Column_Name`                           AS `Alias_Column_Name`,
         `t3`.`Expression_Type_ID`                          AS `Expression_Type_ID`,
         `t4`.`Expression_Type_Desc`                        AS `Expression_Type_Desc`,
         group_concat(`t3`.`Expression_Name` separator ',') AS `expression`
  from ((((`zgh_jghg`.`source_table_column_operation` `t` left join `zgh_jghg`.`source_table_column` `t1` on ((
    `t`.`Column_ID` = `t1`.`Column_ID`))) left join `zgh_jghg`.`source_table` `t2` on ((`t`.`Source_Table_ID` =
                                                                                        `t2`.`Source_Table_ID`))) left join `zgh_jghg`.`expression_table` `t3` on ((
    `t`.`Expression_ID` = `t3`.`Expression_ID`))) left join `zgh_jghg`.`expression_tpye_table` `t4` on ((
    `t3`.`Expression_Type_ID` = `t4`.`Expression_Type_ID`)))
  where ((`t1`.`Is_Delete` = 'N') and (`t2`.`Is_Delete` = 'N') and (`t3`.`Is_Delete` = 'N') and
         (`t4`.`Is_Delete` = 'N'))
  group by `t2`.`Source_Table_ID`, `t2`.`Source_Table_Name`, `t2`.`Source_Table_Zh_Name`, `t1`.`Column_ID`,
           `t1`.`Column_Name`, `t1`.`Column_Type`, `t1`.`Alias_Column_Name`, `t3`.`Expression_Type_ID`;

