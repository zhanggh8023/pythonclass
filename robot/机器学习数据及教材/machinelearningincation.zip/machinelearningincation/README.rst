Machine Learning in Action 
==========================

This is the source code to go with "Machine Learning in Action" 
by Peter Harrington published by Manning Inc.
The official page for this book can be found here: http://manning.com/pharrington/

All the code examples were working on Python 2.6, there shouldn't be any problems with the 2.7.  NumPy will be needed for most examples.  If you have trouble running any of the examples us know on the Forum for this book: http://www.manning-sandbox.com/forum.jspa?forumID=728.  

If you want to run these on some other version of Python say--3.0 or IronPython, feel free to fork the code.   
